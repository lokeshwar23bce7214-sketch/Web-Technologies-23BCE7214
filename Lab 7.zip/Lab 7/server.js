const express = require("express")
const { MongoClient, ObjectId } = require("mongodb")
const cors = require("cors")

const app = express()

app.use(cors())
app.use(express.json())
app.use(express.static("public"))

const url = "mongodb://127.0.0.1:27017"
const client = new MongoClient(url)

let db

async function start(){

await client.connect()

db = client.db("lab7db")

console.log("MongoDB Connected")

}

start()

// ---------------- NOTES CRUD ----------------

app.post("/notes", async (req,res)=>{

await db.collection("notes").insertOne(req.body)

res.send("Note inserted")

})

app.get("/notes", async (req,res)=>{

let notes = await db.collection("notes").find().toArray()

res.send(notes)

})

app.delete("/notes/:id", async (req,res)=>{

await db.collection("notes").deleteOne({_id:new ObjectId(req.params.id)})

res.send("Deleted")

})

// ---------------- BOOK SEARCH ----------------

app.get("/books/search", async (req,res)=>{

let title = req.query.title

let books = await db.collection("books")
.find({title:{$regex:title,$options:"i"}})
.toArray()

res.send(books)

})

app.listen(3000,()=>{

console.log("Server running http://localhost:3000")

})