const API="http://localhost:3000"

function searchBook(){

let title=document.getElementById("search").value

fetch(API+"/books/search?title="+title)
.then(res=>res.json())
.then(data=>{

let html=""

data.forEach(b=>{

html+=`
<div class="book">

<h3>${b.title}</h3>
<p>Author: ${b.author}</p>
<p>Category: ${b.category}</p>
<p>Price: ${b.price}</p>
<p>Rating: ${b.rating}</p>

</div>
`
})

document.getElementById("books").innerHTML=html

})

}