const API="http://localhost:3000"

function addNote(){

let note={
title:document.getElementById("title").value,
subject:document.getElementById("subject").value,
description:document.getElementById("desc").value
}

fetch(API+"/notes",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify(note)
})
.then(()=>loadNotes())

}

function loadNotes(){

fetch(API+"/notes")
.then(res=>res.json())
.then(data=>{

let html=""

data.forEach(n=>{

html+=`
<div class="note">

<h3>${n.title}</h3>
<p><b>${n.subject}</b></p>
<p>${n.description}</p>

<button onclick="deleteNote('${n._id}')">Delete</button>

</div>
`
})

document.getElementById("notes").innerHTML=html

})

}

function deleteNote(id){

fetch(API+"/notes/"+id,{method:"DELETE"})
.then(()=>loadNotes())

}

loadNotes()